NOVA GAME — точные изображения пользователя

Иконка: картинка №10 (242526.jpg) -> app/src/main/res/drawable-nodpi/nova_icon_photo.jpg
Заставка: картинка №5 (176257.jpg) -> app/src/main/res/drawable-nodpi/splash_photo.jpg

Установить содержимое папки app/ в соответствующую папку app/ Android-проекта.
Заменить SplashActivity.kt из архива.
В AndroidManifest.xml изменить android:icon="@drawable/app_icon" на android:icon="@drawable/nova_icon_photo".
Собрать APK через GitHub Actions / Gradle. Подпись APK и applicationId должны оставаться прежними для обновления поверх существующей версии.

Изображения не обрезаются на экране загрузки. Надпись расположена отдельно внизу.
