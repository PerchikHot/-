package com.perchikhot.novagame

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.*
import android.view.View

class SplashActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val next = Runnable {
        if (!isFinishing) {
            startActivity(Intent(this, MenuActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(SplashView())
        handler.postDelayed(next, 3000)
    }
    override fun onDestroy() { handler.removeCallbacks(next); super.onDestroy() }

    private inner class SplashView : View(this@SplashActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val started = android.os.SystemClock.uptimeMillis()
        private val picture = BitmapFactory.decodeResource(resources, R.drawable.splash_photo)
        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val t = (android.os.SystemClock.uptimeMillis() - started) / 1000f
            canvas.drawColor(Color.rgb(9, 9, 29))
            // Keep the entire original illustration visible, without cropping.
            val captionHeight = (h * .15f).coerceAtLeast(110f * resources.displayMetrics.density)
            val imageHeight = h - captionHeight
            val scale = minOf(w / picture.width, imageHeight / picture.height)
            val dw = picture.width * scale
            val dh = picture.height * scale
            val rect = RectF((w - dw) / 2f, (imageHeight - dh) / 2f, (w + dw) / 2f, (imageHeight + dh) / 2f)
            paint.alpha = 255
            canvas.drawBitmap(picture, null, rect, paint)
            paint.color = 0xFF13112D.toInt()
            canvas.drawRect(0f, imageHeight, w, h, paint)
            val transition = ((t % 2.4f) / 2.4f)
            val showFuta = transition >= .5f
            val fade = kotlin.math.abs(kotlin.math.sin(transition * Math.PI)).toFloat()
            paint.color = if (showFuta) 0xFFFF83C7.toInt() else 0xFFD2B0FF.toInt()
            paint.alpha = (190 + fade * 65).toInt().coerceIn(0,255)
            paint.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = w * .086f
            canvas.drawText(if (showFuta) "FUTA GAME" else "NOVA GAME", w / 2f, imageHeight + captionHeight * .53f, paint)
            paint.alpha = 255
            paint.color = 0xFF393052.toInt()
            val left = w * .15f
            val right = w * .85f
            val y = imageHeight + captionHeight * .77f
            canvas.drawRoundRect(left,y,right,y+7f,5f,5f,paint)
            paint.color = 0xFFC07AFF.toInt()
            canvas.drawRoundRect(left,y,left+(right-left)*(t/3f).coerceIn(0f,1f),y+7f,5f,5f,paint)
            postInvalidateDelayed(33)
        }
    }
}
